# Delivery policy walkthrough

Use the matching GWT development build identified in engine.json.
From this directory with the installed gwt command:

```sh
gwt version --json
gwt validate delivery.gwt
gwt validate proposed.gwt
gwt run proposed.gwt --request "quote delivery" --input parcel.json
gwt review delivery.corpus.json --candidate proposed.gwt --html delivery-review.html
```

Open delivery-review.html. Nine cases compare; two fees change from 9 to 5.
The zero-weight failure is preserved. Review decisions start pending.
expected-cases.json contains independent expected before/after results.
A different engine must migrate the original cases explicitly; a source or
engine change may change the identity of the report and invalidate old decisions.
These are illustrative fixtures, not participant responses or a public release.
